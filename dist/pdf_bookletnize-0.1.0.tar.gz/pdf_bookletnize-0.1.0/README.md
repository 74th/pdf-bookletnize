# PDF をブックレット化する

```
poetry install
portry run python booklet.py input.pdf output.pdf
```

生成された PDF を 2 枚レイアウト、短辺綴じで印刷するとブックレットになるはず。
